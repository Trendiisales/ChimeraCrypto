#include <thread>
#include <chrono>
#include <csignal>
#include <atomic>
#include "engine/InstitutionalEngine.hpp"
#include "live/BinanceWSFeed.hpp"
#include "telemetry/TelemetrySpine.hpp"
#include "telemetry/WsTelemetryServer.hpp"
#include "telemetry/DeskSnapshot.hpp"
#include "execution/NetworkLatencySystem.hpp"
#include "execution/ExchangeLatencyEngine.hpp"

chimera::ExchangeLatencyEngine g_exchange_latency;

Chimera::NetworkLatencySystem g_network_latency;

static std::atomic<bool> g_running{true};

struct PriceCache {
    std::atomic<uint64_t> btc_bits{0};
    std::atomic<uint64_t> eth_bits{0};
    std::atomic<uint64_t> sol_bits{0};
    
    void set_btc(double val) {
        uint64_t bits;
        __builtin_memcpy(&bits, &val, sizeof(double));
        btc_bits.store(bits, std::memory_order_relaxed);
    }
    
    void set_eth(double val) {
        uint64_t bits;
        __builtin_memcpy(&bits, &val, sizeof(double));
        eth_bits.store(bits, std::memory_order_relaxed);
    }
    
    void set_sol(double val) {
        uint64_t bits;
        __builtin_memcpy(&bits, &val, sizeof(double));
        sol_bits.store(bits, std::memory_order_relaxed);
    }
    
    double get_btc() const {
        uint64_t bits = btc_bits.load(std::memory_order_relaxed);
        double val;
        __builtin_memcpy(&val, &bits, sizeof(double));
        return val;
    }
    
    double get_eth() const {
        uint64_t bits = eth_bits.load(std::memory_order_relaxed);
        double val;
        __builtin_memcpy(&val, &bits, sizeof(double));
        return val;
    }
    
    double get_sol() const {
        uint64_t bits = sol_bits.load(std::memory_order_relaxed);
        double val;
        __builtin_memcpy(&val, &bits, sizeof(double));
        return val;
    }
} price_cache;

void signal_handler(int) {
    g_running = false;
}

int main() {
    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);

    chimera::InstitutionalEngine engine(10000.0);
    chimera::TelemetrySpine spine;
    chimera::WsTelemetryServer ws_server(9001, spine, "");
    ws_server.start();

    chimera::BinanceWSFeed feed;
    feed.add_symbol("btcusdt");
    feed.add_symbol("ethusdt");
    feed.add_symbol("solusdt");

    feed.set_callback([&engine](const chimera::MarketTick& tick) {
        if (tick.symbol == "btcusdt") price_cache.set_btc(tick.last_price);
        else if (tick.symbol == "ethusdt") price_cache.set_eth(tick.last_price);
        else if (tick.symbol == "solusdt") price_cache.set_sol(tick.last_price);
        
        engine.update_book(tick.symbol, tick.bid, tick.ask, tick.bid_size, tick.ask_size);
        engine.tick(tick.symbol);
    });

    feed.start();

    auto last_snapshot = std::chrono::steady_clock::now();
    chimera::DeskSnapshot snapshot;

    while (g_running) {
        auto now = std::chrono::steady_clock::now();
        
        if (std::chrono::duration_cast<std::chrono::seconds>(now - last_snapshot).count() >= 1) {
            
            snapshot.btc_price = price_cache.get_btc();
            snapshot.eth_price = price_cache.get_eth();
            snapshot.sol_price = price_cache.get_sol();
            
            snapshot.equity = engine.get_equity();
            snapshot.pnl = engine.get_total_pnl();
            snapshot.unrealized_pnl = engine.get_unrealized_pnl();
            snapshot.day_pnl = snapshot.pnl;
            snapshot.latency_ms = g_network_latency.latest();
            snapshot.orders_sent = engine.get_orders_sent();
            snapshot.fills_received = engine.get_fills();
            snapshot.positions = engine.num_positions();
            snapshot.orders_blocked = engine.get_blocked_orders();
            snapshot.governor = engine.get_governor_state();
            snapshot.kill_switch = engine.is_halted();
            
            spine.publish(&snapshot);
            last_snapshot = now;
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    feed.stop();
    ws_server.stop();
    
    return 0;
}
