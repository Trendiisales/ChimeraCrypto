#pragma once
#include <cstdint>
#include <cmath>

namespace chimera {

struct LVConfig {
    double base_cost_bps = 7.0;
    double min_required_edge_bps = 14.0;
    double stop_bps = 8.0;
    double target_bps = 26.0;
    double scale_out_bps = 14.0;
    double imbalance_trigger = 2.4;
    double depth_drop_ratio = 0.30;
    double max_spread_bps = 3.0;
    int depth_window_ticks = 64;
    int cooldown_ms = 800;
};

struct LVPosition {
    bool active = false;
    bool long_side = false;
    double entry_price = 0.0;
    int64_t entry_time = 0;
    bool partial_taken = false;
};

class LiquidityVacuumEngine {
public:
    explicit LiquidityVacuumEngine(const LVConfig& cfg)
        : cfg_(cfg)
    {
        reset();
    }

    void reset()
    {
        idx_ = 0;
        count_ = 0;
        bid_sum_ = 0.0;
        ask_sum_ = 0.0;
        last_mid_ = 0.0;
        cooldown_until_ = 0;
        pos_ = LVPosition();
        signal_enter_ = false;
        signal_exit_ = false;
    }

    void on_book(
        double bid_price,
        double bid_size,
        double ask_price,
        double ask_size,
        int64_t now_ms,
        double latency_p95_ms)
    {
        signal_enter_ = false;
        signal_exit_ = false;

        double mid = (bid_price + ask_price) * 0.5;
        double spread_bps =
            ((ask_price - bid_price) / mid) * 10000.0;

        if (spread_bps > cfg_.max_spread_bps)
            return;

        record_depth(bid_size, ask_size);

        if (!pos_.active)
        {
            if (now_ms >= cooldown_until_)
                evaluate_entry(mid, now_ms, latency_p95_ms);
        }
        else
        {
            manage_position(mid, now_ms);
        }

        last_mid_ = mid;
    }

    bool enter_signal() const { return signal_enter_; }
    bool exit_signal() const { return signal_exit_; }
    bool is_long() const { return pos_.long_side; }
    double entry_price() const { return pos_.entry_price; }
    double exit_price() const { return exit_price_; }

private:
    void record_depth(double bid, double ask)
    {
        bid_sum_ -= bid_buffer_[idx_];
        ask_sum_ -= ask_buffer_[idx_];

        bid_buffer_[idx_] = bid;
        ask_buffer_[idx_] = ask;

        bid_sum_ += bid;
        ask_sum_ += ask;

        idx_ = (idx_ + 1) % DEPTH_CAP;
        if (count_ < DEPTH_CAP)
            count_++;
    }

    double avg_bid() const
    {
        if (count_ == 0) return 0.0;
        return bid_sum_ / count_;
    }

    double avg_ask() const
    {
        if (count_ == 0) return 0.0;
        return ask_sum_ / count_;
    }

    void evaluate_entry(double mid, int64_t now_ms, double latency_p95_ms)
    {
        if (count_ < DEPTH_CAP)
            return;

        double bid_avg = avg_bid();
        double ask_avg = avg_ask();

        if (bid_avg <= 0.0 || ask_avg <= 0.0)
            return;

        double imbalance = bid_avg / ask_avg;

        double impulse_bps = 0.0;
        if (last_mid_ > 0.0)
            impulse_bps =
                std::fabs((mid - last_mid_) / last_mid_) * 10000.0;

        double dynamic_edge =
            cfg_.min_required_edge_bps +
            latency_p95_ms * 0.9;

        if (imbalance > cfg_.imbalance_trigger &&
            impulse_bps > dynamic_edge)
        {
            pos_.active = true;
            pos_.long_side = true;
            pos_.entry_price = mid;
            pos_.entry_time = now_ms;
            pos_.partial_taken = false;
            signal_enter_ = true;
            return;
        }

        if ((1.0 / imbalance) > cfg_.imbalance_trigger &&
            impulse_bps > dynamic_edge)
        {
            pos_.active = true;
            pos_.long_side = false;
            pos_.entry_price = mid;
            pos_.entry_time = now_ms;
            pos_.partial_taken = false;
            signal_enter_ = true;
            return;
        }
    }

    void manage_position(double mid, int64_t now_ms)
    {
        double move_bps =
            ((mid - pos_.entry_price) /
             pos_.entry_price) * 10000.0;

        if (!pos_.long_side)
            move_bps = -move_bps;

        if (!pos_.partial_taken &&
            move_bps >= cfg_.scale_out_bps)
        {
            pos_.partial_taken = true;
        }

        if (move_bps >= cfg_.target_bps)
        {
            exit_price_ = mid;
            pos_.active = false;
            signal_exit_ = true;
            cooldown_until_ = now_ms + cfg_.cooldown_ms;
            return;
        }

        if (move_bps <= -cfg_.stop_bps)
        {
            exit_price_ = mid;
            pos_.active = false;
            signal_exit_ = true;
            cooldown_until_ = now_ms + cfg_.cooldown_ms;
            return;
        }

        if (now_ms - pos_.entry_time > 3500)
        {
            exit_price_ = mid;
            pos_.active = false;
            signal_exit_ = true;
            cooldown_until_ = now_ms + cfg_.cooldown_ms;
        }
    }

private:
    static constexpr int DEPTH_CAP = 64;

    LVConfig cfg_;
    LVPosition pos_;

    double bid_buffer_[DEPTH_CAP]{};
    double ask_buffer_[DEPTH_CAP]{};

    int idx_ = 0;
    int count_ = 0;

    double bid_sum_ = 0.0;
    double ask_sum_ = 0.0;

    double last_mid_ = 0.0;

    int64_t cooldown_until_ = 0;

    bool signal_enter_ = false;
    bool signal_exit_ = false;

    double exit_price_ = 0.0;
};

}
