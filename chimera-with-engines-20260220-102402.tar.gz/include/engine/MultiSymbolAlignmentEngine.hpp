#pragma once
#include <cstdint>
#include <cmath>

namespace chimera {

struct MSAConfig {
    double base_cost_bps = 7.0;
    double min_required_edge_bps = 16.0;
    double stop_bps = 10.0;
    double target_bps = 34.0;
    double scale_out_bps = 18.0;
    double alignment_trigger_bps = 10.0;
    int alignment_window_ticks = 64;
    int cooldown_ms = 1200;
};

struct MSAPosition {
    bool active = false;
    bool long_side = false;
    int symbol_index = -1;
    double entry_price = 0.0;
    int64_t entry_time = 0;
    bool partial_taken = false;
};

class MultiSymbolAlignmentEngine {
public:
    explicit MultiSymbolAlignmentEngine(const MSAConfig& cfg)
        : cfg_(cfg)
    {
        reset();
    }

    void reset()
    {
        for (int i = 0; i < SYMBOLS; ++i) {
            idx_[i] = 0;
            count_[i] = 0;
            sum_[i] = 0.0;
            last_price_[i] = 0.0;
        }

        pos_ = MSAPosition();
        signal_enter_ = false;
        signal_exit_ = false;
        cooldown_until_ = 0;
    }

    void on_tick(
        int symbol_index,
        double price,
        int64_t now_ms,
        double latency_p95_ms)
    {
        signal_enter_ = false;
        signal_exit_ = false;

        if (symbol_index < 0 || symbol_index >= SYMBOLS)
            return;

        update_impulse(symbol_index, price);

        if (!pos_.active) {
            if (now_ms >= cooldown_until_)
                evaluate_alignment(now_ms, latency_p95_ms);
        } else {
            manage_position(symbol_index, price, now_ms);
        }
    }

    bool enter_signal() const { return signal_enter_; }
    bool exit_signal() const { return signal_exit_; }
    bool is_long() const { return pos_.long_side; }
    int symbol() const { return pos_.symbol_index; }
    double entry_price() const { return pos_.entry_price; }
    double exit_price() const { return exit_price_; }

private:
    static constexpr int SYMBOLS = 3;
    static constexpr int BUF = 64;

    void update_impulse(int s, double price)
    {
        if (last_price_[s] > 0.0) {
            double move =
                ((price - last_price_[s]) /
                 last_price_[s]) * 10000.0;

            sum_[s] -= buffer_[s][idx_[s]];
            buffer_[s][idx_[s]] = move;
            sum_[s] += move;

            idx_[s] = (idx_[s] + 1) % BUF;
            if (count_[s] < BUF)
                count_[s]++;
        }

        last_price_[s] = price;
    }

    double avg_impulse(int s) const
    {
        if (count_[s] == 0)
            return 0.0;
        return sum_[s] / count_[s];
    }

    void evaluate_alignment(int64_t now_ms, double latency_p95_ms)
    {
        int strong_count = 0;
        int strongest = -1;
        double strongest_val = 0.0;

        double dynamic_required =
            cfg_.min_required_edge_bps +
            latency_p95_ms * 0.9;

        for (int i = 0; i < SYMBOLS; ++i) {
            double impulse = avg_impulse(i);

            if (std::fabs(impulse) >
                cfg_.alignment_trigger_bps)
            {
                strong_count++;

                if (std::fabs(impulse) >
                    strongest_val)
                {
                    strongest_val =
                        std::fabs(impulse);
                    strongest = i;
                }
            }
        }

        if (strong_count >= 2 &&
            strongest >= 0 &&
            strongest_val > dynamic_required)
        {
            pos_.active = true;
            pos_.symbol_index = strongest;
            pos_.long_side =
                avg_impulse(strongest) > 0.0;
            pos_.entry_price =
                last_price_[strongest];
            pos_.entry_time = now_ms;
            pos_.partial_taken = false;
            signal_enter_ = true;
        }
    }

    void manage_position(
        int symbol_index,
        double price,
        int64_t now_ms)
    {
        if (symbol_index != pos_.symbol_index)
            return;

        double move =
            ((price - pos_.entry_price) /
             pos_.entry_price) * 10000.0;

        if (!pos_.long_side)
            move = -move;

        if (!pos_.partial_taken &&
            move >= cfg_.scale_out_bps)
        {
            pos_.partial_taken = true;
        }

        if (move >= cfg_.target_bps)
        {
            exit_trade(price, now_ms);
            return;
        }

        if (move <= -cfg_.stop_bps)
        {
            exit_trade(price, now_ms);
            return;
        }

        if (now_ms - pos_.entry_time > 4500)
        {
            exit_trade(price, now_ms);
        }
    }

    void exit_trade(double price, int64_t now_ms)
    {
        exit_price_ = price;
        pos_.active = false;
        signal_exit_ = true;
        cooldown_until_ =
            now_ms + cfg_.cooldown_ms;
    }

private:
    MSAConfig cfg_;
    MSAPosition pos_;

    double buffer_[SYMBOLS][BUF]{};
    double sum_[SYMBOLS]{};
    double last_price_[SYMBOLS]{};
    int idx_[SYMBOLS]{};
    int count_[SYMBOLS]{};

    bool signal_enter_ = false;
    bool signal_exit_ = false;

    int64_t cooldown_until_ = 0;
    double exit_price_ = 0.0;
};

}
