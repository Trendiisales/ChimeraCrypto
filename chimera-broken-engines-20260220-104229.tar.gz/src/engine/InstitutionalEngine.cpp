#include "engine/InstitutionalEngine.hpp"
#include <cmath>
#include <algorithm>

extern chimera::ExchangeLatencyEngine g_exchange_latency;
extern chimera::VolatilityExpansionEngine g_ve_engine;
extern chimera::LiquidityVacuumEngine g_lv_engine;
extern chimera::MultiSymbolAlignmentEngine g_msa_engine;

namespace chimera {

InstitutionalEngine::InstitutionalEngine(double initial_capital)
    : equity_(initial_capital)
    , risk_governor_(initial_capital)
    , shadow_executor_(false, risk_governor_, position_ledger_, order_tracker_)
{
}

void InstitutionalEngine::update_book(const std::string& symbol, 
                                     double bid, double ask,
                                     double bid_size, double ask_size)
{
    auto now = std::chrono::system_clock::now();
    int64_t now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count();
    
    double mid = (bid + ask) * 0.5;
    
    int sym_idx = -1;
    if (symbol == "btcusdt") sym_idx = 0;
    else if (symbol == "ethusdt") sym_idx = 1;
    else if (symbol == "solusdt") sym_idx = 2;
    
    if (sym_idx >= 0 && g_exchange_latency.ready()) {
        g_msa_engine.on_tick(sym_idx, mid, now_ms, g_exchange_latency.p95());
        g_ve_engine.on_tick(mid, now_ms, g_exchange_latency.p95());
        g_lv_engine.on_book(bid, bid_size, ask, ask_size, now_ms, g_exchange_latency.p95());
    }
}

void InstitutionalEngine::tick(const std::string& symbol)
{
    if (!g_exchange_latency.ready()) return;
    
    if (g_ve_engine.has_signal()) {
        std::printf("[VE] ENTRY | %s | LONG=%d | px=%.2f\n", 
            symbol.c_str(), g_ve_engine.is_long() ? 1 : 0, g_ve_engine.entry_price());
    }
    
    if (g_ve_engine.exit_ready()) {
        std::printf("[VE] EXIT | px=%.2f\n", g_ve_engine.exit_price());
    }
    
    if (g_lv_engine.enter_signal()) {
        std::printf("[LV] ENTRY | %s | LONG=%d | px=%.2f\n",
            symbol.c_str(), g_lv_engine.is_long() ? 1 : 0, g_lv_engine.entry_price());
    }
    
    if (g_lv_engine.exit_signal()) {
        std::printf("[LV] EXIT | px=%.2f\n", g_lv_engine.exit_price());
    }
    
    if (g_msa_engine.enter_signal()) {
        std::printf("[MSA] ENTRY | sym=%d | LONG=%d | px=%.2f\n",
            g_msa_engine.symbol(), g_msa_engine.is_long() ? 1 : 0, g_msa_engine.entry_price());
    }
    
    if (g_msa_engine.exit_signal()) {
        std::printf("[MSA] EXIT | px=%.2f\n", g_msa_engine.exit_price());
    }
}

}
