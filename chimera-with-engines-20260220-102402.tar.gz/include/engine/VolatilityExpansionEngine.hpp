#pragma once
#include <cstdint>
#include <cmath>

namespace chimera {

struct VEConfig {
    double base_cost_bps = 7.0;
    double min_required_edge_bps = 15.0;
    double stop_bps = 9.0;
    double target_bps = 28.0;
    double vol_multiplier = 1.8;
    double impulse_trigger_bps = 12.0;
    int short_window_ms = 500;
    int long_window_ms = 5000;
};

struct VEState {
    bool in_position = false;
    bool long_side = false;
    double entry_price = 0.0;
    int64_t entry_time_ms = 0;
};

class VolatilityExpansionEngine {
public:
    explicit VolatilityExpansionEngine(const VEConfig& cfg)
        : cfg_(cfg)
    {
        reset();
    }

    void reset()
    {
        short_idx_ = 0;
        long_idx_ = 0;
        short_count_ = 0;
        long_count_ = 0;
        short_sum_ = 0.0;
        long_sum_ = 0.0;
        state_ = VEState();
    }

    void on_tick(double price, int64_t now_ms, double latency_p95_ms)
    {
        if (last_price_ > 0.0) {
            double move_bps = ((price - last_price_) / last_price_) * 10000.0;
            record_short(std::fabs(move_bps));
            record_long(std::fabs(move_bps));
        }

        last_price_ = price;

        if (!state_.in_position)
            try_enter(price, now_ms, latency_p95_ms);
        else
            manage_position(price, now_ms);
    }

    bool has_signal() const { return signal_ready_; }
    bool is_long() const { return state_.long_side; }
    double entry_price() const { return state_.entry_price; }
    double exit_price() const { return exit_price_; }
    bool exit_ready() const { return exit_signal_; }

private:
    void record_short(double v)
    {
        short_sum_ -= short_buffer_[short_idx_];
        short_buffer_[short_idx_] = v;
        short_sum_ += v;
        short_idx_ = (short_idx_ + 1) % SHORT_CAP;
        if (short_count_ < SHORT_CAP) short_count_++;
    }

    void record_long(double v)
    {
        long_sum_ -= long_buffer_[long_idx_];
        long_buffer_[long_idx_] = v;
        long_sum_ += v;
        long_idx_ = (long_idx_ + 1) % LONG_CAP;
        if (long_count_ < LONG_CAP) long_count_++;
    }

    double short_vol() const
    {
        if (short_count_ == 0) return 0.0;
        return short_sum_ / short_count_;
    }

    double long_vol() const
    {
        if (long_count_ == 0) return 0.0;
        return long_sum_ / long_count_;
    }

    void try_enter(double price, int64_t now_ms, double latency_p95_ms)
    {
        if (short_count_ < SHORT_CAP || long_count_ < LONG_CAP)
            return;

        double sv = short_vol();
        double lv = long_vol();

        if (lv <= 0.0) return;

        if (sv > lv * cfg_.vol_multiplier) {
            double impulse_bps = sv;

            double dynamic_required =
                cfg_.min_required_edge_bps +
                (latency_p95_ms * 0.8);

            if (impulse_bps > dynamic_required &&
                impulse_bps > cfg_.impulse_trigger_bps)
            {
                state_.in_position = true;
                state_.long_side = true;
                state_.entry_price = price;
                state_.entry_time_ms = now_ms;
                signal_ready_ = true;
            }
        }
    }

    void manage_position(double price, int64_t now_ms)
    {
        double move_bps =
            ((price - state_.entry_price) /
             state_.entry_price) * 10000.0;

        if (!state_.long_side)
            move_bps = -move_bps;

        if (move_bps >= cfg_.target_bps) {
            exit_signal_ = true;
            exit_price_ = price;
            state_.in_position = false;
            return;
        }

        if (move_bps <= -cfg_.stop_bps) {
            exit_signal_ = true;
            exit_price_ = price;
            state_.in_position = false;
            return;
        }

        if (now_ms - state_.entry_time_ms > 4000) {
            exit_signal_ = true;
            exit_price_ = price;
            state_.in_position = false;
        }
    }

private:
    static constexpr int SHORT_CAP = 64;
    static constexpr int LONG_CAP = 512;

    VEConfig cfg_;
    VEState state_;

    double short_buffer_[SHORT_CAP]{};
    double long_buffer_[LONG_CAP]{};

    int short_idx_ = 0;
    int long_idx_ = 0;
    int short_count_ = 0;
    int long_count_ = 0;

    double short_sum_ = 0.0;
    double long_sum_ = 0.0;

    double last_price_ = 0.0;

    bool signal_ready_ = false;
    bool exit_signal_ = false;
    double exit_price_ = 0.0;
};

}
